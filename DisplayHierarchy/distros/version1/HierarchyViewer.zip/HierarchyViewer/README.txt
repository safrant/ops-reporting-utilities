Run as such:

C:\> HierarchyViewer cdrh_flatfile.txt C62596 "FDA CDRH Terminology"